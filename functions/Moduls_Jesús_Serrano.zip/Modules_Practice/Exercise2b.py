from Maths import basic_operations as ob

# b) Import the basic_operations module, and call it's functions using bo instead of basic_operations.

a, b = 13, 3

print('operands =', a, b)
print('add =', ob.add(a, b))
print('subtract =', ob.subtract(a, b))
print('multiply =', ob.multiply(a, b))
print('divide =', ob.divide(a, b))
