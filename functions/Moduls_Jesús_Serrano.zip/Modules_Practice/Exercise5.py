from Exercise3 import username_check
from Exercise4 import password_check

user = input('Enter a username: ')
pwd = input('Enter a password: ')
print(username_check(user))
print(password_check(pwd))
