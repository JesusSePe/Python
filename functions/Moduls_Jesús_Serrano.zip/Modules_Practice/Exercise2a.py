from Maths import basic_operations


# a) Import basic_operations and execute the following instructions without errors:
a, b = 13, 3

print('operands =', a, b)
print('add =', basic_operations.add(a, b))
print('subtract =', basic_operations.subtract(a, b))
print('multiply =', basic_operations.multiply(a, b))
print('divide =', basic_operations.divide(a, b))
