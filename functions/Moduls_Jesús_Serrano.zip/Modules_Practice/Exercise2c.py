from Maths.basic_operations import add, subtract, multiply, divide

# c) Import the basic_operations module, and call it's functions without using prefixes.

a, b = 13, 3

print('operands =', a, b)
print('add =', add(a, b))
print('subtract =', subtract(a, b))
print('multiply =', multiply(a, b))
print('divide =', divide(a, b))
