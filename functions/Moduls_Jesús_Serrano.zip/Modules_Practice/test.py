from Maths import basic_operations

print(basic_operations.add(2, 3))
print(basic_operations.subtract(5, 3))
print(basic_operations.multiply(7, 7))
print(basic_operations.divide(4, 0))
